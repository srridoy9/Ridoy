# Accordion Component


## Options
No options available for this component

## Install
```
import Accordion from 'components/Accordion'
```

## Examples
```
<Accordion />
```