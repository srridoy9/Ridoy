# Footer Component


## Options
No options available for this component

## Install
```
import Footer from 'components/Footer'
```

## Examples
```
<Footer />
```