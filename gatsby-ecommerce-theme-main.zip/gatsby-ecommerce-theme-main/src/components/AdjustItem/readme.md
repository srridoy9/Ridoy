# AdjustItem Component


## Options
No options available for this component

## Install
```
import AdjustItem from 'components/AdjustItem'
```

## Examples
```
<AdjustItem />
```