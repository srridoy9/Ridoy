# RemoveItem Component


## Options
No options available for this component

## Install
```
import RemoveItem from 'components/RemoveItem'
```

## Examples
```
<RemoveItem />
```