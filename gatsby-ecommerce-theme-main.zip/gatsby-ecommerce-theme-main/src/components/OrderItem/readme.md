# OrderItem Component


## Options
No options available for this component

## Install
```
import OrderItem from 'components/OrderItem'
```

## Examples
```
<OrderItem />
```