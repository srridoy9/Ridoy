# BlogPreviewGrid Component


## Options
No options available for this component

## Install
```
import BlogPreviewGrid from 'components/BlogPreviewGrid'
```

## Examples
```
<BlogPreviewGrid />
```