export { default } from './Policy';
