export { default } from './Quote';
