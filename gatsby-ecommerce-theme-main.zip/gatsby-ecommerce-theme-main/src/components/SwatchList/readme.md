# SwatchList Component


## Options
No options available for this component

## Install
```
import SwatchList from 'components/SwatchList'
```

## Examples
```
<SwatchList />
```