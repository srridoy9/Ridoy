export { default } from './Banner';
