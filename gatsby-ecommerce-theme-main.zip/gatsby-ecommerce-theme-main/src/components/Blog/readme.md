# Blog Component


## Options
No options available for this component

## Install
```
import Blog from 'components/Blog'
```

## Examples
```
<Blog />
```