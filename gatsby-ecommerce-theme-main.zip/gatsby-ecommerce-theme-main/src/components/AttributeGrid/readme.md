# AttributeGrid Component


## Options
No options available for this component

## Install
```
import AttributeGrid from 'components/AttributeGrid'
```

## Examples
```
<AttributeGrid />
```