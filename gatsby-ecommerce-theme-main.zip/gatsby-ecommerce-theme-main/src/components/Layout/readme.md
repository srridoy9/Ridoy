# Layout Component
This component is responsible for loading footer, helmet and header subcomponents. Also responsible for loading global styling

## Options
No options available for this component

## Install
```
import Layout from 'components/Layout'
```

## Examples
```
<Layout />
```