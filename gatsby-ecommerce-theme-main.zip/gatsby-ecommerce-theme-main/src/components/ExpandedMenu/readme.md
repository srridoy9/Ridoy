# ExpandedMenu Component
expanded menu for the header

## Options
No options available for this component

## Install
```
import ExpandedMenu from 'components/ExpandedMenu'
```

## Examples
```
<ExpandedMenu />
```