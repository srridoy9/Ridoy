# Button Component


## Options
No options available for this component

## Install
```
import Button from 'components/Button'
```

## Examples
```
<Button />
```