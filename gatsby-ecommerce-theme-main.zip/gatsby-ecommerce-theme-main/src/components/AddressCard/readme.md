# AddressCard Component


## Options
No options available for this component

## Install
```
import AddressCard from 'components/AddressCard'
```

## Examples
```
<AddressCard />
```