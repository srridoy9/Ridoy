export { default } from './MiniCartItem';
