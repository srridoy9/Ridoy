export { default } from './ProductCollection';
